$(document).ready (function () {
    $(document).on('click','.livrer',function(){
        alert("La commande a été livré");
    });
});